﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System;
using System.Security.Permissions;

[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]

[assembly: AssemblyTitle("Aga.Controls")]
[assembly: AssemblyCopyright("Copyright © Andrey Gliznetsov 2006 - 2007")]
[assembly: AssemblyDescription("http://sourceforge.net/projects/treeviewadv/")]

[assembly: AssemblyVersion("1.6.0.0")]
[assembly: AssemblyProductAttribute("Aga.Controls")]
