# CRUD_App
This repository is of developing an CRUD operation application using JDBC
